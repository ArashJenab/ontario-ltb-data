# Data Sources

This project uses public datasets only. None is scraped, purchased, or private; all are published for reuse by the agencies that produced them.

Two supply the analysis itself (the LTB order catalogue and the census). The rest are published figures used as independent checks and comparisons, so that no claim here rests on this analysis alone. A figure-by-figure map of which number came from where is at [`sources.html`](sources.html).

## Ontario Landlord and Tenant Board: LTB Order Catalogue

- **Publisher**: Landlord and Tenant Board (Ontario Ministry of the Attorney General)
- **Dataset**: [LTB Order Catalogue](https://data.ontario.ca/dataset/ltb-order-catalogue), via the Ontario Data Catalogue
- **License**: [Open Government Licence, Ontario](https://www.ontario.ca/page/open-government-licence-ontario)
- **What it contains**: copies of final orders issued by the LTB, published in phases (historical orders from 2021 onward; orders subject to confidentiality orders are excluded)
- **Accessed via**: the dataset's [CKAN Data API](https://data.ontario.ca/dataset/ltb-order-catalogue) (`datastore_search`, resource id `86e75d11-1c2c-4cd9-9b0d-9fccec302b30`), not a manual browser export
- **Used here as**: `data/ltb_open_data_export.json`, the snapshot this analysis is built from (49,269 records, orders issued 2026-01-02 to 2026-06-30, retrieved 2026-10-01)
- **How current it is**: the Board adds orders to the catalogue in batches, about three months after they issue. The 2026-08-13 fetch ended at orders dated 2026-05-29; the 2026-10-01 fetch added 8,425 orders, all but three dated June 2026, and removed none. So the newest order in the file was 93 days old on the day it was retrieved, and that gap is the publisher's, not this repository's.

### Keeping the snapshot current

`python scripts/fetch_ltb_orders.py` re-pulls the full dataset from the CKAN API and decides whether to adopt it:

- Every fetch is archived to `data/snapshots/` (gitignored local backup, last 5 kept), regardless of outcome.
- The fetch is compared against the current `data/ltb_open_data_export.json` by Document ID: records added + removed, as a percentage of the old total ("churn").
- Below the churn threshold (default 10%, `--threshold` to change it): the fetch is **dismissed**. A few thousand new orders on top of ~40,000 is expected drift, not enough to skew the aggregate stats or invalidate the existing proportional dollar-amount sample.
- At or above the threshold: the fetch is **adopted** (`data/ltb_open_data_export.json` is overwritten) and the script prints a reminder to bring the PDF samples up to date, which is deliberately not automatic because it means downloading order documents from a public server.
- The samples are then extended rather than redrawn: `python scripts/extract_case_details.py --top-up-after <last date of the old window>` keeps every order already read and draws the newly published ones at the same sampling fraction, so the combined sample stays proportional. The 2026-10-01 refresh was done this way, with `--top-up-after 2026-05-29`.
- Every run, adopted or not, is logged to `data/fetch_log.csv` (tracked in git) as an audit trail of what changed and what was decided.

Run it whenever you want a refresh; nothing in the pipeline calls it automatically.

Under the Open Government Licence (Ontario), you're free to copy, modify, publish, translate, and distribute this information, including commercially, provided you attribute the source and don't imply endorsement by the Ontario government or the LTB. This repository's use complies with those terms; the license applies to the LTB data itself, independent of this repo's own [MIT license](LICENSE) on the analysis code.

## Statistics Canada, 2021 Census: population, tenure and income

- **Publisher**: Statistics Canada
- **Tables**:
  - 98-10-0019-01, *"Population and dwelling counts: Canada and forward sortation areas"*, [statcan.gc.ca](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=9810001901)
  - 98-10-0002-01, *"Population and dwelling counts: Canada and census subdivisions (municipalities)"*, [statcan.gc.ca](https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=9810000201)
  - 98-401-X2021013, *Census Profile, Forward Sortation Areas*, [statcan.gc.ca](https://www150.statcan.gc.ca/n1/en/catalogue/98-401-X2021013). Fetched by `scripts/fetch_fsa_census_profile.py` and reduced to `data/fsa_census_profile.csv` (521 Ontario FSAs). Supplies the **renter-household** denominator used for every rate in the report, plus median household income, average and median rent, share of tenants in core housing need, and share paying 30%+ of income on shelter.

    A per-resident rate largely measures how many renters an area has rather than how much dispute activity it has, which is why the renter-household denominator replaced it. As a check that the extraction reads the right field: renter households summed across Ontario FSAs come to 1,725,025 against a province-level 1,724,970, a 55-household gap that is census random rounding.
- **Boundaries**: 2021 Census Cartographic Boundary Files, via the ArcGIS REST feature service: [FSA layer](https://geo.statcan.gc.ca/geo_wa/rest/services/2021/Cartographic_boundary_files/MapServer/14) and [Census Subdivision (municipality) layer](https://geo.statcan.gc.ca/geo_wa/rest/services/2021/Cartographic_boundary_files/MapServer/9)
- **License**: [Statistics Canada Open Licence](https://www.statcan.gc.ca/en/terms-conditions/open-licence)
- **Used here as**: `data/fsa_population.csv` + `data/ontario_fsa_simplified.geojson` (FSA-level), and `data/csd_population.csv` + `data/ontario_csd_simplified.geojson` (municipality-level). All are simplified for file size, see `data/README.md`

Under the Statistics Canada Open Licence, this data may be used, reproduced, and redistributed for any purpose, commercial or non-commercial, provided Statistics Canada is credited as the source. Attribution used throughout this repo: *"Statistics Canada, table 98-10-0019-01 / 98-10-0002-01, 2021 Census."*

## Published figures used as checks and comparisons

These are not inputs to the analysis. Each is a published number used to test whether
this analysis's own figures are plausible, or to give them a scale a reader can judge.
All are cited in place on the site.

- **Tribunals Ontario, 2024-25 Annual Report** ([tribunalsontario.ca](https://tribunalsontario.ca/documents/TO/Tribunals_Ontario_2024-2025_Annual_Report.html)).
  The Board's own intake: 87,993 applications received, 72,836 of them filed by
  landlords. Used as an independent route to the annual case rate. A different fiscal
  year from the order export, so the two are reported as separate routes to the same
  quantity rather than combined.
- **Statistics Canada, Canadian Housing Survey 2021**, *Evictions in Canada*
  ([statcan.gc.ca](https://www150.statcan.gc.ca/n1/pub/11-627-m/11-627-m2022046-eng.htm)),
  Statistics Canada Open Licence. The reasons renters give for being forced to move:
  sale of the property 37%, landlord's own use 26%, conflict 13%, demolition or
  repairs 10%, behind on rent 8%. National rather than Ontario-only, and used to
  compare the *shape* of recorded reasons against reported ones, never to produce an
  Ontario count.
- **CMHC (July 2025)**, *Towards Understanding the Magnitude of Evictions in Canada*
  ([cmhc-schl.gc.ca](https://assets.cmhc-schl.gc.ca/sites/cmhc/professional/housing-markets-data-and-research/housing-research/research-reports/2025/towards-understanding-magnitude-evictions-en.pdf)).
  That about 1.0% of Canadian renters are evicted in a year counting both formal and
  informal evictions. This is the figure that separates "a case was filed" from
  "someone lost their home". CMHC notes the survey excludes people in shelters and
  institutions, so it undercounts.
- **The Eviction Lab, Princeton University**, Eviction Tracking System 2024
  ([evictionlab.org](https://evictionlab.org/ets-report-2024/)). About 8 eviction
  filings per 100 renter households across tracked United States cities. US court
  procedure differs from Ontario's, so this is a rough scale comparison and is
  labelled as one.

## Name-gender inference

Where the report discusses the gender of parties, it is inferred from first names using
the `gender-guesser` dictionary (offline, no network call, no personal data sent
anywhere). This is a weak instrument and is reported only alongside its coverage rate,
because the misses are not random: the dictionary resolves Anglo and European given
names far better than others. It is not a data source about anyone; it is a lookup
applied to names already published in the LTB export.

## What this repo adds

Everything in `results/` and `data/*normalized*` / `data/*payload*` is **derived** from the sources above: joins, per-capita rates, sampled dollar-amount extractions, and the map. These derived outputs are original analysis and are covered by this repository's own [MIT license](LICENSE); they are not official statistics from either source agency, and neither agency has reviewed or endorsed this analysis.

## Reference year and currency of the data

The LTB export used here holds orders issued 2026-01-02 to 2026-06-30 and was retrieved on 2026-10-01. Population figures are the 2021 Census, the most recent available at time of writing. Some drift between the two reference periods is expected and noted where relevant (e.g. `results/applications_by_area/README.md`).
